<?php
require_once "config.php";

function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

$mess = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $uname = trim($_POST['uname'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    // CHECK IF PASSWORDS MATCH
    if ($password !== $password2) {

        $errors[] = "Password should match.";

    } elseif (empty($uname)) {

        $errors[] = "Username is required.";

    } elseif (strlen($password) < 8) {

        $errors[] = "Password must be at least 8 characters.";

    } else {

        // HASH PASSWORD
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // PREPARE SQL
        $stmt = $conn->prepare(
            "INSERT INTO users (username, password) VALUES (?, ?)"
        );

        if ($stmt) {

            // BIND PARAMETERS
            $stmt->bind_param("ss", $uname, $hashedPassword);

            // EXECUTE QUERY
            if ($stmt->execute()) {

                $mess[] = "Registered successfully. Please wait for the admin approval of your account.";

            } else {

                $errors[] = "Registration failed: " . $stmt->error;
            }

            $stmt->close();

        } else {

            $errors[] = "Database error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register</title>
</head>

<body>

    <h1>Clinic Patient Record</h1>
    <h2>Create your Account</h2>

    <br>

    <?php foreach ($errors as $e): ?>
        <p style="color:red;">
            <?= h($e) ?>
        </p>
    <?php endforeach; ?>

    <?php foreach ($mess as $m): ?>
        <p style="color:green;">
            <?= h($m) ?>
        </p>
    <?php endforeach; ?>

    <form action="" method="POST">

        <label>Username:</label>

        <input
            type="text"
            name="uname"
            placeholder="Enter username"
            required
            autofocus
        >

        <br><br>

        <label>Password:</label>

        <input
            type="password"
            name="password"
            placeholder="Enter password"
            required
        >

        <br><br>

        <label>Re-enter password:</label>

        <input
            type="password"
            name="password2"
            placeholder="Re-enter password"
            required
        >

        <br><br>

        <input type="submit" value="Register">

    </form>

    <br><br>

    <p>Already have an account?
        <a href="index.php">Sign In</a>
    </p>

</body>
</html>
